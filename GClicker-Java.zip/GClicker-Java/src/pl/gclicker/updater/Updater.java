package pl.gclicker.updater;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import pl.gclicker.Main;
import pl.gclicker.gui.LoginGui;
import pl.gclicker.gui.UpdaterGui;

public class Updater {
    private static String version = Main.VERSION;
    
    public static void download() {
        new Thread(new Runnable(){

            @Override
            public void run() {
                try {
                    int count;
                    URL url = new URL("http://site19225.web1.titanaxe.com/updater/GClicker.jar");
                    BufferedInputStream bis = new BufferedInputStream(url.openStream());
                    FileOutputStream fos = new FileOutputStream(String.valueOf(System.getenv("APPDATA")) + File.separator + "gclicker" + File.separator + "GClicker.jar");
                    byte[] buffer = new byte[1024];
                    while ((count = bis.read(buffer, 0, 1024)) != -1) {
                        fos.write(buffer, 0, count);
                    }
                    fos.close();
                    bis.close();
                    System.exit(0);
                    return;
                }
                catch (Exception url) {
                    // empty catch block
                }
            }
        }).run();
    }
    
    public static void checkVersion() {
		try {
            String inputLine;
            URL website = new URL("http://site19225.web1.titanaxe.com/updater/version.file");
            URLConnection connection = website.openConnection();
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            while ((inputLine = in.readLine()) != null) {
                if (version.equals(inputLine)) {
                	LoginGui.start();
                	continue;
                }
                UpdaterGui.start();
            }
            return;
        }
        catch (MalformedURLException e) {
        	LoginGui.start();
        	return;
        }
        catch (IOException e2) {
        }
    }
}
