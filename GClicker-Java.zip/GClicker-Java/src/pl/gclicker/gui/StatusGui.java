package pl.gclicker.gui;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JWindow;

public class StatusGui {
	public static JWindow frame = new JWindow();
	public static JLabel macroLeftEnabled;
	public static JLabel macroRightEnabled;
	public static JLabel kopanieEnabled;
	
	public static void start() {	
		JPanel panel = new JPanel();
		frame.setSize(300, 150);
		frame.setVisible(true);
		frame.setAlwaysOnTop(true);
        frame.setBackground(new Color(0,0,0,0));
		frame.add(panel);
		
		panel.setLayout(null);
		panel.setBounds(0, 0, 300, 100);
		
		JLabel gclickerText = new JLabel("GClicker.PL");
		gclickerText.setBounds(10,0,125,25);
		gclickerText.setForeground(Color.CYAN);
		gclickerText.setFont(new Font("Bahnschrift", Font.BOLD, 18));
		panel.add(gclickerText);
		
		macroLeftEnabled = new JLabel("Lewy Clicker: OFF");
		macroLeftEnabled.setBounds(10, 25, 125, 25);
		macroLeftEnabled.setForeground(Color.RED);
		macroLeftEnabled.setFont(new Font("Bahnschrift", Font.BOLD, 12));
		panel.add(macroLeftEnabled);
		
		macroRightEnabled = new JLabel("Prawy Clicker: OFF");
		macroRightEnabled.setBounds(10, 50, 125, 25);
		macroRightEnabled.setForeground(Color.RED);
		macroRightEnabled.setFont(new Font("Bahnschrift", Font.BOLD, 12));
		panel.add(macroRightEnabled);
		
		kopanieEnabled = new JLabel("Kopanie: OFF");
		kopanieEnabled.setBounds(10, 75, 125, 25);
		kopanieEnabled.setForeground(Color.RED);
		kopanieEnabled.setFont(new Font("Bahnschrift", Font.BOLD, 12));
		panel.add(kopanieEnabled);
		
		panel.setBackground(new Color(0,0,0,0));
	}
}