/*
 * Decompiled with CFR 0.150.
 */
package pl.gclicker.listener.left;

import java.awt.AWTException;
import java.awt.Robot;
import java.util.Random;

import pl.gclicker.Main;
import pl.gclicker.gui.ClickerGui;

public class ClickerL {
    public static /* synthetic */ boolean run;
    private static /* synthetic */ Robot robot;
    public static /* synthetic */ boolean ignore;
    private static /* synthetic */ int delay;
    public static /* synthetic */ long lastTime;
    public static /* synthetic */ boolean mineFirst;
    public static int IleDoGardy = 0;

    static /* synthetic */ {
        run = false;
        ignore = false;
        delay = -1;
        lastTime = 0L;
        mineFirst = false;
    }

    public /* synthetic */ ClickerL() {
        try {
            robot = new Robot();
        }
        catch (AWTException e) {
            e.printStackTrace();
        }
    }

    public static /* synthetic */ void Clicker() {
        try {
            while (true) {
                Thread.sleep(1L);
                Random random = new Random();
                if (delay == -1) {
                    delay = random.nextInt(1000 / Main.minCPS - 1000 / Main.maxCPS + 1) + 1000 / Main.maxCPS;
                }
                if (!Main.inMinecraft() || !run || !KeyListenL.toggled || System.currentTimeMillis() - lastTime < (long)delay) continue;
                ignore = true;
                robot.mousePress(16);
                robot.mouseRelease(16);
                
                if(ClickerGui.autogardaLpm.isSelected()) {
	               	IleDoGardy++;
		           	if(IleDoGardy == 8) {
		           		robot.mousePress(4);
		           		robot.mouseRelease(4);
		           		IleDoGardy=0;
		           }
                }
                
                lastTime = System.currentTimeMillis();
                delay = random.nextInt(1000 / Main.minCPS - 1000 / Main.maxCPS + 1) + 1000 / Main.maxCPS;
            }
        }
        catch (InterruptedException e) {
            e.printStackTrace();
            return;
        }
    }
}

