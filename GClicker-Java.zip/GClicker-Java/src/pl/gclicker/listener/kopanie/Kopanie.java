package pl.gclicker.listener.kopanie;

import java.awt.AWTException;
import java.awt.Robot;
import java.util.Timer;
import java.util.TimerTask;

import pl.gclicker.Main;
import pl.gclicker.gui.ClickerGui;

public class Kopanie {
    static /* synthetic */ double czas;
    static double czas2;

    public /* synthetic */ Kopanie() {
    	Main.size = Integer.parseInt(ClickerGui.stoniarkaSize.getText());
        Main.up = Integer.parseInt(ClickerGui.stoniarkaUp.getText());
        Main.repairCommand = ClickerGui.aktywacjaRepairCommand.isSelected();
        Main.command2 = ClickerGui.aktywacja2.isSelected();
        Main.command3 = ClickerGui.aktywacja3.isSelected();
        Main.command4 = ClickerGui.aktywacja4.isSelected();
        Main.command5 = ClickerGui.aktywacja5.isSelected();
        if (Main.repairCommand) {
            Main.command = ClickerGui.komenda.getText();
        }
        if (Main.command2) {
            Main.cmd2 = ClickerGui.komenda2.getText();
        }
        if (Main.command3) {
            Main.cmd3 = ClickerGui.komenda3.getText();
        }
        if (Main.command4) {
            Main.cmd4 = ClickerGui.komenda4.getText();
        }
        if (Main.command5) {
            Main.cmd5 = ClickerGui.komenda5.getText();
        }
        if (Main.eats = ClickerGui.radioButton_2.isSelected()) {
            Main.slotEats = ClickerGui.slotJedzenie.getText();
        }
        Main.slotsKilof = Integer.parseInt(ClickerGui.slotKilof.getText());
        Main.turaJedzenie = 0;
        Main.turaKilof = 0;
        Main.tur2 = 0;
        Main.tur3 = 0;
        Main.tur4 = 0;
        Main.tur5 = 0;
        Kopanie.Start();
    }

    public static /* synthetic */ void Start() {
        czas = (double)Main.size * 0.22;
        czas2 = (double)Main.size *0.22;
        Kopanie.goRight();
    }

    public static /* synthetic */ void goRight() {
        Timer timer = new Timer();
        try {
            final Robot robot = new Robot();
            robot.mousePress(16);
            robot.keyPress(68);
            timer.schedule(new TimerTask(){

                @Override
                public /* synthetic */ void run() {
                    robot.keyRelease(68);
                    if (KeyListenBind.toggled) {
                        Kopanie.goUp();
                    }
                }
            }, (long)(czas * 1000.0));
        }
        catch (AWTException e) {
            e.printStackTrace();
        }
    }
    
    public static void goUp() {
        Timer timer = new Timer();
        try {
            final Robot robot = new Robot();
            robot.keyPress(87);
            timer.schedule(new TimerTask(){

                @Override
                public /* synthetic */ void run() {
                	robot.keyRelease(87);
                	if(KeyListenBind.toggled) {
                    	Kopanie.goLeft();
                	}
                }
            }, (long)(czas2 * 1000.0));
        }
        catch (AWTException e) {
            e.printStackTrace();
        }
    }

    public static /* synthetic */ void goLeft() {
        Timer timer = new Timer();
        try {
            final Robot robot = new Robot();
            robot.keyPress(65);
            timer.schedule(new TimerTask(){

                @Override
                public /* synthetic */ void run() {
                    robot.keyRelease(65);
                    if(KeyListenBind.toggled) {
                    	Kopanie.goDown();
                    }
                }
            }, (long)(czas * 1000.0));
        }
        catch (AWTException e) {
            e.printStackTrace();
        }
    }
    
    public static /* synthetic */ void goDown() {
        Timer timer = new Timer();
        try {
            final Robot robot = new Robot();
            robot.keyPress(83);
            timer.schedule(new TimerTask(){

                @Override
                public /* synthetic */ void run() {
                    robot.keyRelease(83);
                    ++Main.turaKilof;
                    ++Main.tur2;
                    ++Main.tur3;
                    ++Main.tur4;
                    ++Main.tur5;
                    ++Main.turaJedzenie;
                    Kopanie.nextTur();
                }
            }, (long)(czas2 * 1000.0));
        }
        catch (AWTException e) {
            e.printStackTrace();
        }
    }

    public static /* synthetic */ void nextTur() {
        if (Main.repairCommand && Main.turaKilof == Integer.parseInt(ClickerGui.turRepairKilof.getText())) {
            Main.turaKilof = 0;
            Kopanie.RepairCommand();
        } else if(Main.command2 && Main.tur2 == Integer.parseInt(ClickerGui.tur2.getText())) {
        	Main.tur2 = 0;
        	Kopanie.command2();
        } else if(Main.command3 && Main.tur3 == Integer.parseInt(ClickerGui.tur3.getText())) {
        	Main.tur3 = 0;
        	Kopanie.command3();
        } else if(Main.command4 && Main.tur4 == Integer.parseInt(ClickerGui.tur4.getText())) {
        	Main.tur4 = 0;
        	Kopanie.command4();
        } else if(Main.command5 && Main.tur5 == Integer.parseInt(ClickerGui.tur5.getText())) {
        	Main.tur5 = 0;
        	Kopanie.command5();
    	} else if (Main.eats && Main.turaJedzenie == Integer.parseInt(ClickerGui.turJedzenie.getText())) {
            Main.turaJedzenie = 0;
            Kopanie.Jedzenie();
        } else if (KeyListenBind.toggled) {
            try {
                Robot robot = new Robot();
                char slot = ClickerGui.slotKilof.getText().charAt(0);
                robot.keyPress(slot);
                robot.keyRelease(slot);
            }
            catch (AWTException e) {
                e.printStackTrace();
            }
            Kopanie.goRight();
        }
    }

    public static /* synthetic */ void RepairCommand() {
        try {
            Robot robot = new Robot();
            robot.keyPress(84);
            robot.keyRelease(84);
            robot.delay(250);
            String commandCpas = ClickerGui.komenda.getText().toUpperCase();
            for (int i = 0; i < commandCpas.length(); ++i) {
                char lol = commandCpas.charAt(i);
                robot.keyPress(lol);
                robot.keyRelease(lol);
            }
            robot.keyPress(10);
            robot.keyRelease(10);
            robot.delay(250);
            Kopanie.nextTur();
        }
        catch (AWTException e) {
            e.printStackTrace();
        }
    }
    
    public static /* synthetic */ void command2() {
        try {
            Robot robot = new Robot();
            robot.keyPress(84);
            robot.keyRelease(84);
            robot.delay(250);
            String commandCpas = ClickerGui.komenda2.getText().toUpperCase();
            for (int i = 0; i < commandCpas.length(); ++i) {
                char lol = commandCpas.charAt(i);
                robot.keyPress(lol);
                robot.keyRelease(lol);
            }
            robot.keyPress(10);
            robot.keyRelease(10);
            robot.delay(250);
            Kopanie.nextTur();
        }
        catch (AWTException e) {
            e.printStackTrace();
        }
    }
    
    public static /* synthetic */ void command3() {
        try {
            Robot robot = new Robot();
            robot.keyPress(84);
            robot.keyRelease(84);
            robot.delay(250);
            String commandCpas = ClickerGui.komenda3.getText().toUpperCase();
            for (int i = 0; i < commandCpas.length(); ++i) {
                char lol = commandCpas.charAt(i);
                robot.keyPress(lol);
                robot.keyRelease(lol);
            }
            robot.keyPress(10);
            robot.keyRelease(10);
            robot.delay(250);
            Kopanie.nextTur();
        }
        catch (AWTException e) {
            e.printStackTrace();
        }
    }
    
    public static /* synthetic */ void command4() {
        try {
            Robot robot = new Robot();
            robot.keyPress(84);
            robot.keyRelease(84);
            robot.delay(250);
            String commandCpas = ClickerGui.komenda4.getText().toUpperCase();
            for (int i = 0; i < commandCpas.length(); ++i) {
                char lol = commandCpas.charAt(i);
                robot.keyPress(lol);
                robot.keyRelease(lol);
            }
            robot.keyPress(10);
            robot.keyRelease(10);
            robot.delay(250);
            Kopanie.nextTur();
        }
        catch (AWTException e) {
            e.printStackTrace();
        }
    }
    
    public static /* synthetic */ void command5() {
        try {
            Robot robot = new Robot();
            robot.keyPress(84);
            robot.keyRelease(84);
            robot.delay(250);
            String commandCpas = ClickerGui.komenda5.getText().toUpperCase();
            for (int i = 0; i < commandCpas.length(); ++i) {
                char lol = commandCpas.charAt(i);
                robot.keyPress(lol);
                robot.keyRelease(lol);
            }
            robot.keyPress(10);
            robot.keyRelease(10);
            robot.delay(250);
            Kopanie.nextTur();
        }
        catch (AWTException e) {
            e.printStackTrace();
        }
    }

    public static /* synthetic */ void Jedzenie() {
        try {
            final Robot robot = new Robot();
            robot.mouseRelease(16);
            char slot = Main.slotEats.charAt(0);
            robot.keyPress(slot);
            robot.keyRelease(slot);
            Timer timer = new Timer();
            timer.schedule(new TimerTask(){

                @Override
                public /* synthetic */ void run() {
                    robot.mouseRelease(4);
                    Kopanie.nextTur();
                }
            }, 4000L);
            robot.mousePress(4);
        }
        catch (AWTException e) {
            e.printStackTrace();
        }
    }

    public static /* synthetic */ void Stop() {
        try {
            Robot robot = new Robot();
            robot.keyRelease(68);
            robot.keyRelease(65);
            robot.mouseRelease(16);
        }
        catch (AWTException e) {
            e.printStackTrace();
        }
    }
}


