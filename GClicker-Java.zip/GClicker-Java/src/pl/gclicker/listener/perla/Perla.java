package pl.gclicker.listener.perla;

import java.awt.AWTException;
import java.awt.Robot;

import pl.gclicker.Main;
import pl.gclicker.gui.ClickerGui;

public class Perla {
    public Perla() {
        Perla.Start();
    }

    public static /* synthetic */ void Start() {
    	try {
    		Robot robot = new Robot();
            String slotPunch = ClickerGui.slotPerla.getText().toUpperCase();
            for (int i = 0; i < slotPunch.length(); ++i) {
                char lol = slotPunch.charAt(i);
                robot.keyPress(lol);
                robot.keyRelease(lol);
            }
            robot.mousePress(4);
            robot.mouseRelease(4);
            Thread.sleep(123);
            String slotMiecz = ClickerGui.slotMiecz.getText().toUpperCase();
            for (int i = 0; i < slotMiecz.length(); ++i) {
                char lol = slotMiecz.charAt(i);
                robot.keyPress(lol);
                robot.keyRelease(lol);
            }
    	} catch(AWTException e) {
    		e.printStackTrace();
    	} catch (InterruptedException e) {
			e.printStackTrace();
		}
    }
}