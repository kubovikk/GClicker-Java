/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.jnativehook.keyboard.NativeKeyEvent
 *  org.jnativehook.keyboard.NativeKeyListener
 */
package pl.gclicker.listener.right;

import java.awt.Color;
import java.util.ArrayList;

import com.github.kwhat.jnativehook.keyboard.NativeKeyEvent;
import com.github.kwhat.jnativehook.keyboard.NativeKeyListener;

import pl.gclicker.Main;
import pl.gclicker.gui.ClickerGui;
import pl.gclicker.gui.StatusGui;

public class KeyListenP
implements NativeKeyListener {
    private /* synthetic */ ArrayList<Integer> pressed;
    public /* synthetic */ ArrayList<Integer> localKeyCode;
    public static /* synthetic */ boolean usingMouseToggle;
    public static /* synthetic */ Integer toggleKeyCode;
    public static volatile /* synthetic */ boolean toggled;

    static /* synthetic */ {
        usingMouseToggle = false;
        toggled = false;
    }

    public /* synthetic */ KeyListenP() {
        this.pressed = new ArrayList();
        this.localKeyCode = new ArrayList();
    }

    public /* synthetic */ void nativeKeyPressed(NativeKeyEvent e) {
        this.pressed.add(e.getKeyCode());
        if (Main.keyListenP && e.getKeyCode() != 29 && e.getKeyCode() != 42 && e.getKeyCode() != 3675) {
            usingMouseToggle = false;
            this.localKeyCode = new ArrayList();
            for (int i = 0; i < this.pressed.size(); ++i) {
                this.localKeyCode.add(this.pressed.get(i));
            }
            String setText = "Aktywowanie (";
            if (this.localKeyCode.size() == 1) {
                setText = String.valueOf(setText) + NativeKeyEvent.getKeyText((int)this.localKeyCode.get(0)) + ")";
            } else {
                for (int i = 0; i < this.localKeyCode.size() - 1; ++i) {
                    setText = String.valueOf(setText) + NativeKeyEvent.getKeyText((int)this.localKeyCode.get(i)) + "+";
                }
                setText = String.valueOf(setText) + NativeKeyEvent.getKeyText((int)this.localKeyCode.get(this.localKeyCode.size() - 1)) + "]";
            }
            toggleKeyCode = (int)this.localKeyCode.get(0);
            ClickerGui.btnAktywowanief.setText(setText);
            Main.keyListenP = false;
        } else if (this.pressed.contains(toggleKeyCode) && !Main.keyListenP && !usingMouseToggle) {
            boolean bl = toggled = !toggled;
            if (toggled) {
                ClickerGui.MacroP.setText("true");
                ClickerGui.MacroP.setForeground(Color.GREEN);
                StatusGui.frame.repaint();
                StatusGui.macroRightEnabled.setText("Prawy Clicker: ON");
                StatusGui.macroRightEnabled.setForeground(Color.GREEN);
            } else {
                ClickerGui.MacroP.setText("false");
                ClickerGui.MacroP.setForeground(Color.RED);
                StatusGui.frame.repaint();
                StatusGui.macroRightEnabled.setText("Prawy Clicker: OFF");
                StatusGui.macroRightEnabled.setForeground(Color.RED);
            }
        }
    }

    public /* synthetic */ void nativeKeyReleased(NativeKeyEvent e) {
        this.pressed = new ArrayList();
    }

    public /* synthetic */ void nativeKeyTyped(NativeKeyEvent e) {
    }
}

