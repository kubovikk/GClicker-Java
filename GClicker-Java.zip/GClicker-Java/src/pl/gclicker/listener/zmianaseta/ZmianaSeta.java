package pl.gclicker.listener.zmianaseta;

import java.awt.AWTException;
import java.awt.Robot;

public class ZmianaSeta {
    public /* synthetic */ ZmianaSeta() {
        ZmianaSeta.Start();
    }

    public static /* synthetic */ void Start() {
    	try {
    		Robot robot = new Robot();
    		robot.keyPress(69);
    		robot.keyRelease(69);
    		Thread.sleep(100);
    		robot.mousePress(16);
    		robot.mouseMove(657,557);
    		robot.mouseRelease(16);
    		Thread.sleep(100);
    		robot.mousePress(16);
    		robot.mouseMove(670,258);
    		robot.mouseRelease(16);
    		Thread.sleep(100);
    		robot.mousePress(16);
    		robot.mouseMove(657,557);
    		robot.mouseRelease(16);
    		Thread.sleep(100);
    		robot.mousePress(16);
    		robot.mouseMove(744,557);
    		robot.mouseRelease(16);
    		Thread.sleep(100);
    		robot.mousePress(16);
    		robot.mouseMove(674,327);
    		robot.mouseRelease(16);
    		Thread.sleep(100);
    		robot.mousePress(16);
    		robot.mouseMove(744,557);
    		robot.mouseRelease(16);
    		Thread.sleep(100);
    		robot.mousePress(16);
    		robot.mouseMove(663,407);
    		robot.mouseRelease(16);
    		Thread.sleep(100);
    		robot.mousePress(16);
    		robot.mouseMove(816,560);
    		robot.mouseRelease(16);
    		Thread.sleep(100);
    		robot.mousePress(16);
    		robot.mouseMove(816,560);
    		robot.mouseRelease(16);
    		Thread.sleep(100);
    		robot.mousePress(16);
    		robot.mouseMove(674,477);
    		robot.mouseRelease(16);
    		Thread.sleep(100);
    		robot.mousePress(16);
    		robot.mouseMove(890,561);
    		robot.mouseRelease(16);
    		Thread.sleep(100);
    		robot.mousePress(16);
    		robot.mouseMove(958,565);
    		robot.mouseRelease(16);
    		Thread.sleep(100);
    		robot.keyPress(69);
    		robot.keyRelease(69);
    	} catch(AWTException e) {
    		e.printStackTrace();
    	} catch (InterruptedException e) {
			e.printStackTrace();
		}
    }
}
