package pl.gclicker;

import java.awt.AWTException;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Robot;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JOptionPane;

import com.github.kwhat.jnativehook.GlobalScreen;
import com.github.kwhat.jnativehook.NativeHookException;
import com.github.kwhat.jnativehook.keyboard.NativeKeyEvent;
import com.github.kwhat.jnativehook.keyboard.NativeKeyListener;
import com.github.kwhat.jnativehook.mouse.NativeMouseListener;
import com.sun.jna.Native;
import com.sun.jna.platform.win32.User32;
import com.sun.jna.platform.win32.WinDef;

import pl.gclicker.gui.ClickerGui;
import pl.gclicker.gui.LoginGui;
import pl.gclicker.listener.kopanie.KeyListenBind;
import pl.gclicker.listener.left.ClickerL;
import pl.gclicker.listener.left.KeyListenL;
import pl.gclicker.listener.left.MouseListenL;
import pl.gclicker.listener.perla.PerlaListenBind;
import pl.gclicker.listener.punch.PunchListenBind;
import pl.gclicker.listener.right.ClickerP;
import pl.gclicker.listener.right.KeyListenP;
import pl.gclicker.listener.right.MouseListenP;
import pl.gclicker.listener.sniezka.SniezkaListenBind;
import pl.gclicker.listener.wedka.WedkaListenBind;
import pl.gclicker.listener.zmianaseta.ZmianaSetaListenBind;
import pl.gclicker.updater.NetUtil;
import pl.gclicker.updater.Updater;

public class Main {	
	public static volatile /* synthetic */ MouseListenP MLP;
	public static volatile /* synthetic */ MouseListenL MLL;
    public static volatile /* synthetic */ KeyListenP KLP;
    public static volatile /* synthetic */ KeyListenL KLL;
    public static /* synthetic */ boolean keyListenP;
    public static /* ClClickerGuiClickerGuiickerGuisynthetic */ boolean keyListenL;
    public static /* synthetic */ boolean left;
    public static /* synthetic */ boolean right;
    public static /* synthetic */ int minCPS;
    public static /* synthetic */ int maxCPS;
    public static /* synthetic */ int ms;
    public static boolean Pignore;
    public static /* synthetic */ boolean keyListenBind;
    public static boolean zmianaSetaListen;
    public static boolean punchListen;
    public static boolean sniezkaListen;
    public static boolean perlaListen;
    public static boolean wedkaListen;
    public static volatile /* synthetic */ KeyListenBind KLB;
    public static volatile ZmianaSetaListenBind ZSL;
    public static volatile PunchListenBind PLB;
    public static volatile SniezkaListenBind SLB;
    public static volatile PerlaListenBind PLB2;
    public static volatile WedkaListenBind WLB;
    public static /* synthetic */ int size;
    public static int up;
    public static /* synthetic */ boolean repairCommand;
    public static /* synthetic */ boolean command2;
    public static /* synthetic */ boolean command3;
    public static /* synthetic */ boolean command4;
    public static /* synthetic */ boolean command5;
    public static /* synthetic */ String command;
    public static /* synthetic */ String cmd2;
    public static /* synthetic */ String cmd3;
    public static /* synthetic */ String cmd4;
    public static /* synthetic */ String cmd5;
    public static /* synthetic */ boolean eats;
    public static /* synthetic */ String slotEats;
    public static /* synthetic */ int slotsKilof;
    public static /* synthetic */ int turaZloto;
    public static /* synthetic */ int turaJedzenie;
    public static /* synthetic */ int turaKilof;
    public static /* synthetic */ int tur2;
    public static /* synthetic */ int tur3;
    public static /* synthetic */ int tur4;
    public static /* synthetic */ int tur5;
    public static Color ramkacolor;
    
    static /* synthetic */ {
        keyListenP = false;
        keyListenL = false;
        minCPS = 9;
        maxCPS = 15;
        ms = 20;
        Pignore = false;
        keyListenBind = false;
        repairCommand = false;
        command2 = false;
        command3 = false;
        command4 = false;
        command5 = false;
        eats = false;
        zmianaSetaListen = false;
        punchListen = false;
        sniezkaListen = false;
        perlaListen = false;
        wedkaListen = false;
        ramkacolor = new Color(113, 0, 253);
    }
	
	public static String VERSION = "1.5";
	
	public static boolean inMinecraft() {
        char[] buffer = new char[2048];
        WinDef.HWND hwnd = User32.INSTANCE.GetForegroundWindow();
        User32.INSTANCE.GetWindowText(hwnd, buffer, 1024);
        return Native.toString((char[])buffer).contains("Minecraft");
	}
	
	public static void rememberMeSave() throws IOException {
		Properties prop = new Properties();
		prop.setProperty("License", String.valueOf(LoginGui.userText.getText()));
        FileWriter writer = new FileWriter("license.properties");
        prop.store(writer, "Autor: _Kubov1337");
        writer.close();
	}
	
	public static void rememberMeLoad() throws IOException {
        FileReader reader = new FileReader("license.properties");
        Properties prop = new Properties();
        prop.load(reader);
        LoginGui.userText.setText(String.valueOf(prop.getProperty("License")));
	}
	
	public static void saveConfig() throws IOException {
		Properties prop = new Properties();
		prop.setProperty("Bind-Lpm", String.valueOf(KeyListenL.toggleKeyCode));
		prop.setProperty("MinCps-Lpm", String.valueOf(minCPS));
		prop.setProperty("MaxCps-Lpm", String.valueOf(maxCPS));
		prop.setProperty("Bind-Ppm", String.valueOf(KeyListenP.toggleKeyCode));
		prop.setProperty("Cps-Ppm", String.valueOf(ms));
		prop.setProperty("Bind-Set", String.valueOf(ZmianaSetaListenBind.toggleKeyCode));
		prop.setProperty("Bind-Punch", String.valueOf(PunchListenBind.toggleKeyCode));
		prop.setProperty("Bind-Snow", String.valueOf(SniezkaListenBind.toggleKeyCode));
		prop.setProperty("Bind-Pearl", String.valueOf(PerlaListenBind.toggleKeyCode));
		prop.setProperty("Bind-Wedka", String.valueOf(WedkaListenBind.toggleKeyCode));
		prop.setProperty("Kopanie-Dlugosc", String.valueOf(ClickerGui.stoniarkaSize.getText()));
		prop.setProperty("Kopanie-Szerokosc", String.valueOf(ClickerGui.stoniarkaUp.getText()));
		prop.setProperty("Kopanie-Naprawianie-Enabled", String.valueOf(repairCommand));
		prop.setProperty("Kopanie-Komenda2-Enabled", String.valueOf(command2));
		prop.setProperty("Kopanie-Komenda3-Enabled", String.valueOf(command3));
		prop.setProperty("Kopanie-Komenda4-Enabled", String.valueOf(command4));
		prop.setProperty("Kopanie-Komenda5-Enabled", String.valueOf(command5));
		prop.setProperty("Kopanie-Jedzenie-Enabled", String.valueOf(eats));
		prop.setProperty("Kopanie-Naprawianie-Komenda", String.valueOf(ClickerGui.komenda.getText()));
		prop.setProperty("Kopanie-Komenda2", String.valueOf(ClickerGui.komenda2.getText()));
		prop.setProperty("Kopanie-Komenda3", String.valueOf(ClickerGui.komenda3.getText()));
		prop.setProperty("Kopanie-Komenda4", String.valueOf(ClickerGui.komenda4.getText()));
		prop.setProperty("Kopanie-Komenda5", String.valueOf(ClickerGui.komenda5.getText()));
		prop.setProperty("Kopanie-Jedzenie-Slot", String.valueOf(ClickerGui.slotJedzenie.getText()));
		prop.setProperty("Kopanie-Kilof", String.valueOf(ClickerGui.slotKilof.getText()));
		prop.setProperty("Kopanie-Jedzenie-Tur", String.valueOf(ClickerGui.turJedzenie.getText()));
		prop.setProperty("Kopanie-Naprawianie-Tur", String.valueOf(ClickerGui.turRepairKilof.getText()));
		prop.setProperty("Kopanie-Tur2", String.valueOf(ClickerGui.tur2.getText()));
		prop.setProperty("Kopanie-Tur3", String.valueOf(ClickerGui.tur3.getText()));
		prop.setProperty("Kopanie-Tur4", String.valueOf(ClickerGui.tur4.getText()));
		prop.setProperty("Kopanie-Tur5", String.valueOf(ClickerGui.tur5.getText()));
		prop.setProperty("Kopanie-Bind", String.valueOf(KeyListenBind.toggleKeyCode));
		prop.setProperty("Slot-Miecz", ClickerGui.slotMiecz.getText());
		prop.setProperty("Slot-Punch", ClickerGui.slotPunch.getText());
		prop.setProperty("Slot-Sniezka", ClickerGui.slotSniezka.getText());
		prop.setProperty("Slot-Wedka", ClickerGui.slotWedka.getText());
		prop.setProperty("Slot-Perla", ClickerGui.slotPerla.getText());
		prop.setProperty("Autogarda-Enabled", String.valueOf(ClickerGui.autogardaLpm.isSelected()));
        FileWriter writer = new FileWriter("config.properties");
        prop.store(writer, "Autor: _Kubov1337");
        writer.close();
	}
	
	public static void loadConfig() throws IOException {
        FileReader reader = new FileReader("config.properties");
        Properties prop = new Properties();
        prop.load(reader);
        minCPS = Integer.parseInt(prop.getProperty("MinCps-Lpm"));
        maxCPS = Integer.parseInt(prop.getProperty("MaxCps-Lpm"));
        ms = Integer.parseInt(prop.getProperty("Cps-Ppm"));
        KeyListenL.toggleKeyCode = Integer.parseInt(prop.getProperty("Bind-Lpm"));
        KeyListenP.toggleKeyCode = Integer.parseInt(prop.getProperty("Bind-Ppm"));
        ZmianaSetaListenBind.toggleKeyCode = Integer.parseInt(prop.getProperty("Bind-Set"));
        PunchListenBind.toggleKeyCode = Integer.parseInt(prop.getProperty("Bind-Punch"));
        SniezkaListenBind.toggleKeyCode = Integer.parseInt(prop.getProperty("Bind-Snow"));
        PerlaListenBind.toggleKeyCode = Integer.parseInt(prop.getProperty("Bind-Pearl"));
        WedkaListenBind.toggleKeyCode = Integer.parseInt(prop.getProperty("Bind-Wedka"));
        KeyListenBind.toggleKeyCode = Integer.parseInt(prop.getProperty("Kopanie-Bind"));
        repairCommand = Boolean.parseBoolean(prop.getProperty("Kopanie-Naprawianie-Enabled"));
        command2 = Boolean.parseBoolean(prop.getProperty("Kopanie-Komenda2-Enabled"));
        command3 = Boolean.parseBoolean(prop.getProperty("Kopanie-Komenda3-Enabled"));
        command4 = Boolean.parseBoolean(prop.getProperty("Kopanie-Komenda4-Enabled"));
        command5 = Boolean.parseBoolean(prop.getProperty("Kopanie-Komenda5-Enabled"));
        eats = Boolean.parseBoolean(prop.getProperty("Kopanie-Jedzenie-Enabled"));
        /*                                                                    */
        ClickerGui.btnAktywowanief_1.setText("Aktywowanie (" + NativeKeyEvent.getKeyText((int)KeyListenL.toggleKeyCode) + ")");
        ClickerGui.btnAktywowanief.setText("Aktywowanie (" + NativeKeyEvent.getKeyText((int)KeyListenP.toggleKeyCode) + ")");
        ClickerGui.cpsMinSlider.setValue(minCPS);
        ClickerGui.cpsMaxSlider.setValue(maxCPS);
        ClickerGui.ppmSlider.setValue(ms);
        ClickerGui.buttonZmianaSeta.setText("Aktywowanie (" + NativeKeyEvent.getKeyText((int)ZmianaSetaListenBind.toggleKeyCode) + ")");
        ClickerGui.buttonPunchowanie.setText("Aktywowanie (" + NativeKeyEvent.getKeyText((int)PunchListenBind.toggleKeyCode) + ")");
        ClickerGui.buttonSniezka.setText("Aktywowanie (" + NativeKeyEvent.getKeyText((int)SniezkaListenBind.toggleKeyCode) + ")");
        ClickerGui.buttonPerla.setText("Aktywowanie (" + NativeKeyEvent.getKeyText((int)PerlaListenBind.toggleKeyCode) + ")");
        ClickerGui.buttonWedka.setText("Aktywowanie (" + NativeKeyEvent.getKeyText((int)WedkaListenBind.toggleKeyCode) + ")");
        ClickerGui.aktywacjaRepairCommand.setSelected(repairCommand);
        ClickerGui.aktywacja2.setSelected(command2);
        ClickerGui.aktywacja3.setSelected(command3);
        ClickerGui.aktywacja4.setSelected(command4);
        ClickerGui.aktywacja5.setSelected(command5);
        ClickerGui.radioButton_2.setSelected(eats);
        ClickerGui.komenda.setText(prop.getProperty("Kopanie-Naprawianie-Komenda"));
        ClickerGui.komenda2.setText(prop.getProperty("Kopanie-Komenda2"));
        ClickerGui.komenda3.setText(prop.getProperty("Kopanie-Komenda3"));
        ClickerGui.komenda4.setText(prop.getProperty("Kopanie-Komenda4"));
        ClickerGui.komenda5.setText(prop.getProperty("Kopanie-Komenda5"));
        ClickerGui.slotKilof.setText(prop.getProperty("Kopanie-Kilof"));
        ClickerGui.slotJedzenie.setText(prop.getProperty("Kopanie-Jedzenie-Slot"));
        ClickerGui.turJedzenie.setText(prop.getProperty("Kopanie-Jedzenie-Tur"));
        ClickerGui.turRepairKilof.setText(prop.getProperty("Kopanie-Naprawianie-Tur"));
        ClickerGui.tur2.setText(prop.getProperty("Kopanie-Tur2"));
        ClickerGui.tur3.setText(prop.getProperty("Kopanie-Tur3"));
        ClickerGui.tur4.setText(prop.getProperty("Kopanie-Tur4"));
        ClickerGui.tur5.setText(prop.getProperty("Kopanie-Tur5"));
        ClickerGui.buttonAktywacja.setText("Aktywowanie (" + NativeKeyEvent.getKeyText((int)KeyListenBind.toggleKeyCode) + ")");
        ClickerGui.slotMiecz.setText(prop.getProperty("Slot-Miecz"));
        ClickerGui.slotPunch.setText(prop.getProperty("Slot-Punch"));
        ClickerGui.slotSniezka.setText(prop.getProperty("Slot-Sniezka"));
        ClickerGui.slotWedka.setText(prop.getProperty("Slot-Wedka"));
        ClickerGui.slotPerla.setText(prop.getProperty("Slot-Perla"));
        ClickerGui.stoniarkaSize.setText(prop.getProperty("Kopanie-Dlugosc"));
        ClickerGui.stoniarkaUp.setText(prop.getProperty("Kopanie-Szerokosc"));
        ClickerGui.autogardaLpm.setSelected(Boolean.parseBoolean(prop.getProperty("Autogarda-Enabled")));
	}
	
    public static /* synthetic */ void main(String[] args) {
        Timer timer = new Timer();
        EventQueue.invokeLater(new Runnable(){

            @Override
            public void run() {
                try {
                	if (NetUtil.check()) {
                        System.out.println("Polaczono z internetem, sprawdzanie aktualizacji...");
                        Updater.checkVersion();
                	} else {
                        System.out.println("Brak polaczenia z internetem! Zglos to na discordzie!");
                        LoginGui.start();
                    }
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        KeyListenP.toggleKeyCode = 62;
        KeyListenL.toggleKeyCode = 62;
        KeyListenBind.toggleKeyCode = 62;
        ZmianaSetaListenBind.toggleKeyCode = 62;
        PunchListenBind.toggleKeyCode = 62;
        SniezkaListenBind.toggleKeyCode = 62;
        PerlaListenBind.toggleKeyCode = 62;
        WedkaListenBind.toggleKeyCode = 62;
        Logger logger = Logger.getLogger(GlobalScreen.class.getPackage().getName());
        logger.setLevel(Level.OFF);
        logger.setUseParentHandlers(false);
        try {
            GlobalScreen.registerNativeHook();
        }
        catch (NativeHookException e) {
            JOptionPane.showMessageDialog(null, "Couldn't register the native hook.");
            System.exit(1);
        }
        KLB = new KeyListenBind();
        KLP = new KeyListenP();
        KLL = new KeyListenL();
        MLP = new MouseListenP();
        MLL = new MouseListenL();
        ZSL = new ZmianaSetaListenBind();
        PLB = new PunchListenBind();
        SLB = new SniezkaListenBind();
        PLB2 = new PerlaListenBind();
        WLB = new WedkaListenBind();
        GlobalScreen.addNativeKeyListener((NativeKeyListener)KLP);
        GlobalScreen.addNativeKeyListener((NativeKeyListener)KLL);
        GlobalScreen.addNativeMouseListener((NativeMouseListener)MLP);
        GlobalScreen.addNativeMouseListener((NativeMouseListener)MLL);
        GlobalScreen.addNativeKeyListener((NativeKeyListener)KLB);
        GlobalScreen.addNativeKeyListener((NativeKeyListener)ZSL);
        GlobalScreen.addNativeKeyListener((NativeKeyListener)PLB);
        GlobalScreen.addNativeKeyListener((NativeKeyListener)SLB);
        GlobalScreen.addNativeKeyListener((NativeKeyListener)PLB2);
        GlobalScreen.addNativeKeyListener((NativeKeyListener)WLB);
        try {
            Robot robot = new Robot();
        }
        catch (AWTException e) {
            JOptionPane.showMessageDialog(null, "AWTException thrown while instantiating Robot.");
            System.exit(1);
        }
        timer.schedule(new TimerTask() {

			@Override
			public void run() {
				ClickerP.Clicker();
			}
        	
        }, 1000L);
        ClickerL.Clicker();
    }
}